import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pandas as pd
import matplotlib.pyplot as plt
from pyspark.sql import SparkSession
from data_analysis import runDataAnalysis
import subprocess
import os

class DataAnalysisApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Análise de Dados")
        self.root.geometry("1280x920")

        self.salesFile = ""
        self.inventoryFile = ""
        self.leadtimeFile = ""

        self.createWidgets()
        self.spark = self.initializeSpark()

    def createWidgets(self):
        self.root.columnconfigure(0, weight=1)
        self.root.columnconfigure(1, weight=1)
        self.root.columnconfigure(2, weight=1)

        self.salesButton = tk.Button(self.root, text="Selecione o arquivo CSV de vendas", command=self.selectSalesFile)
        self.salesButton.grid(row=0, column=0, padx=10, pady=10, sticky="ew")
        self.salesButton.config(bg='gray', fg='black')

        self.inventoryButton = tk.Button(self.root, text="Selecione o arquivo CSV de estoque",
                                         command=self.selectInventoryFile)
        self.inventoryButton.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        self.inventoryButton.config(bg='gray', fg='black')

        self.leadtimeButton = tk.Button(self.root, text="Selecione o arquivo CSV de Lead time de fornecedores",
                                        command=self.selectLeadtimeFile)
        self.leadtimeButton.grid(row=0, column=2, padx=10, pady=10, sticky="ew")
        self.leadtimeButton.config(bg='gray', fg='black')

        self.startButton = tk.Button(self.root, text="Executar análise", command=self.startAnalysis)
        self.startButton.grid(row=1, column=0, columnspan=3, padx=10, pady=10, sticky="ew")
        self.startButton.config(bg='green', fg='white')

        self.figure = Figure(figsize=(8, 6), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.root)
        self.canvas.get_tk_widget().grid(row=2, column=0, columnspan=3, padx=10, pady=10)

    def selectSalesFile(self):
        self.salesFile = filedialog.askopenfilename(title="Seleção de arquivo CSV de vendas",
                                                    filetypes=[("CSV files", "*.csv")])
        if self.salesFile:
            messagebox.showinfo("Arquivo selecionado", f"Arquivo CSV de vendas: {self.salesFile}")

    def selectInventoryFile(self):
        self.inventoryFile = filedialog.askopenfilename(title="Seleção de arquivo CSV de inventário",
                                                        filetypes=[("CSV files", "*.csv")])
        if self.inventoryFile:
            messagebox.showinfo("Arquivo selecionado", f"Arquivo CSV de estoque: {self.inventoryFile}")

    def selectLeadtimeFile(self):
        self.leadtimeFile = filedialog.askopenfilename(title="Seleção de arquivo CSV de lead time de fornecedores",
                                                       filetypes=[("CSV files", "*.csv")])
        if self.leadtimeFile:
            messagebox.showinfo("Arquivo selecionado", f"Arquivo CSV de lead time: {self.leadtimeFile}")

    def initializeSpark(self):
        return SparkSession.builder \
            .appName("InventoryForecast") \
            .config("spark.hadoop.fs.defaultFS", "hdfs://localhost:9000") \
            .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
            .getOrCreate()


    def startAnalysis(self):
        script_path = r"C:\hadoop\sbin\start-all.cmd"
        subprocess.run([script_path], shell=True)

        if (self.salesFile and self.inventoryFile and self.leadtimeFile):
            os.system(f"hdfs dfs -put -f {self.salesFile} /data/sales.csv")
            os.system(f"hdfs dfs -put -f {self.inventoryFile} /data/inventory.csv")
            os.system(f"hdfs dfs -put -f {self.leadtimeFile} /data/suppliers_leadtime.csv")

        try:
            predictions = runDataAnalysis(self.spark)
            self.plotPredictions(predictions)
            if predictions:
                predictions.show()
                messagebox.showinfo("Sucesso", "Análise completada com sucesso!")
            else:
                messagebox.showwarning("Aviso", "Nenhuma previsão foi gerada.")

        except Exception as e:
            messagebox.showerror("Erro", f"Ocorreu um erro: {e}")

    def plotPredictions(self, predictions):
        self.figure.clear()

        predictions_df = predictions.select("Id do Produto", "Data", "Quantidade Vendida", "prediction").toPandas()

        predictions_df['Data'] = pd.to_datetime(predictions_df['Data'])
        predictions_df['Ano-Mês'] = predictions_df['Data'].dt.to_period('M')

        last_date = predictions_df['Data'].max()
        forecast_periods = pd.date_range(start=last_date, periods=4, freq='M')[1:]  # Próximos 3 meses
        predictions_df = predictions_df[predictions_df['Data'].isin(forecast_periods)]

        aggregated_df = predictions_df.groupby(['Id do Produto', 'Ano-Mês']).agg({
            'Quantidade Vendida': 'sum',
            'prediction': 'sum'
        }).reset_index()

        products = aggregated_df['Id do Produto'].unique()
        for product in products:
            product_df = aggregated_df[aggregated_df['Id do Produto'] == product]
            ax = self.figure.add_subplot(111)
            ax.plot(product_df['Ano-Mês'].astype(str), product_df['Quantidade Vendida'], label='Quantidade Vendida',
                    marker='o')
            ax.plot(product_df['Ano-Mês'].astype(str), product_df['prediction'], label='Predição', marker='o')
            ax.set_title(f'Previsões para o Produto {product}')
            ax.set_xlabel('Mês')
            ax.set_ylabel('Quantidade')
            ax.legend()
            ax.grid(True)

        self.canvas.draw()

if __name__ == "__main__":
    root = tk.Tk()
    app = DataAnalysisApp(root)
    root.mainloop()