from pyspark.sql import SparkSession
from pyspark.sql.functions import col, month, year, to_date
from pyspark.sql.types import IntegerType
import subprocess

def dataPreprocess(spark: SparkSession):
    try:
        inventoryDf = spark.read.csv("hdfs:///data/inventory.csv", header=True, inferSchema=True)
        salesDf = spark.read.csv("hdfs:///data/sales.csv", header=True, inferSchema=True)
        leadtimeDf = spark.read.csv("hdfs:///data/suppliers_leadtime.csv", header=True, inferSchema=True)

        inventoryDf = inventoryDf.dropna()
        salesDf = salesDf.dropna()
        leadtimeDf = leadtimeDf.dropna()

        inventoryDf = inventoryDf.withColumn("Quantidade em Estoque", col("Quantidade em Estoque").cast(IntegerType()))
        inventoryDf = inventoryDf.withColumn("Quantidade Vendida", col("Quantidade Vendida").cast(IntegerType()))
        leadtimeDf = leadtimeDf.withColumn("Lead Time Total (Dias)", col("Lead Time Total (Dias)").cast(IntegerType()))

        salesDf = salesDf.withColumn("Data", to_date(col("Data da Venda"), "dd/MM/yy"))
        salesDf = salesDf.withColumn("Mês", month(col("Data")))
        salesDf = salesDf.withColumn("Ano", year(col("Data")))

        inventoryDf = inventoryDf.withColumnRenamed("Preço Unitário", "Preço Unitário (Estoque)")
        inventoryDf = inventoryDf.withColumnRenamed("Nome do Produto", "Nome do Produto (Estoque)")
        salesDf = salesDf.withColumnRenamed("Preço Unitário", "Preço Unitário (Vendas)")
        salesDf = salesDf.withColumnRenamed("Nome do Produto", "Nome do Produto (Vendas)")

        combinedDf = salesDf.join(inventoryDf, on='Id do Produto', how='inner')
        combinedDf = combinedDf.join(leadtimeDf, on='Fornecedor', how='left')

        combinedDf = combinedDf.dropna()
        return combinedDf

    except Exception as e:
        print(f"Ocorreu um erro durante o pré-processamento dos dados: {e}")

if __name__ == "__main__":
    script_path1 = r"C:\hadoop\sbin\stop-all.cmd"
    subprocess.run([script_path1], shell=True)

    script_path2 = r"C:\hadoop\sbin\start-all.cmd"
    subprocess.run([script_path2], shell=True)

    spark = SparkSession.builder \
        .appName("InventoryForecast") \
        .config("spark.hadoop.fs.defaultFS", "hdfs://localhost:9000") \
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
        .getOrCreate()

    combinedDf = dataPreprocess(spark)

    if combinedDf is not None:
        combinedDf.show(20)
    else:
        print("Nenhum dado retornado. Verifique a função de pré-processamento.")

    spark.stop()