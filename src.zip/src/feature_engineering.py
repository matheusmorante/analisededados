from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler, StringIndexer
from data_preprocessing import dataPreprocess
import subprocess

def createFeatures(preprocessedData,  spark: SparkSession):
    indexer = StringIndexer(inputCol='Nome do Produto (Estoque)', outputCol='ProdutoIndex')
    indexedDf = indexer.fit(preprocessedData).transform(preprocessedData)

    featureCols = ['ProdutoIndex', 'Quantidade em Estoque', 'Lead Time Total (Dias)', 'Mês', 'Ano']
    labelCol = 'Quantidade Vendida'

    assembler = VectorAssembler(inputCols=featureCols, outputCol='features')

    transformedDf = assembler.transform(indexedDf)

    finalDf = transformedDf.select('features', labelCol)

    return finalDf

if __name__ == "__main__":
    script_path1 = r"C:\hadoop\sbin\stop-all.cmd"
    subprocess.run([script_path1], shell=True)

    script_path2 = r"C:\hadoop\sbin\start-all.cmd"
    subprocess.run([script_path2], shell=True)

    spark = SparkSession.builder \
        .appName("InventoryForecast") \
        .config("spark.hadoop.fs.defaultFS", "hdfs://localhost:9000") \
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
        .getOrCreate()

    preprocessedData = dataPreprocess(spark)
    features = createFeatures(preprocessedData, spark)

    if features is not None:
        features.show(30)
    else:
        print("Nenhum dado retornado. Verifique a função de criar features.")

    spark.stop()