from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import LinearRegression
from data_preprocessing import dataPreprocess
from feature_engineering import createFeatures
import subprocess

def trainModel(features):
    trainDf, testDf = features.randomSplit([0.8, 0.2], seed=1234)

    lr = LinearRegression(featuresCol='features', labelCol='Quantidade Vendida')

    model = lr.fit(trainDf)
    return model, testDf

def makePredictions(model, testDf):
    predictions = model.transform(testDf)

    return predictions

if __name__ == "__main__":
    script_path1 = r"C:\hadoop\sbin\stop-all.cmd"
    subprocess.run([script_path1], shell=True)

    script_path2 = r"C:\hadoop\sbin\start-all.cmd"
    subprocess.run([script_path2], shell=True)

    spark = SparkSession.builder \
        .appName("InventoryForecast") \
        .config("spark.hadoop.fs.defaultFS", "hdfs://localhost:9000") \
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
        .getOrCreate()

    preprocessedData = dataPreprocess(spark)
    features = createFeatures(preprocessedData, spark)
    model, testDf = trainModel(features)
    predictions = makePredictions(model, testDf)

    if predictions is not None:
        predictions.select("features", "Quantidade Vendida", "prediction")
    else:
        print("Nenhuma predição retornada. Verifique a função de criar predição.")

    spark.stop()