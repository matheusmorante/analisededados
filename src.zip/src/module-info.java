/**
 * 
 */
/**
 * 
 */
module inventorysystem {
	requires java.sql;
}