from pyspark.sql import SparkSession
from data_preprocessing import dataPreprocess
from feature_engineering import createFeatures
from model import trainModel, makePredictions
import subprocess

def runDataAnalysis(spark: SparkSession):
    try:
        preprocessedData = dataPreprocess(spark)
        features = createFeatures(preprocessedData, spark)

        model, testDf = trainModel(features)
        predictions = makePredictions(model, testDf)

        return predictions
    except Exception as e:
        print(f"Ocorreu um erro durante a análise de dados: {e}")
        return None
