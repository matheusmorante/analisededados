from pyspark.sql import SparkSession
from pyspark.ml.feature import IndexToString
from data_preprocessing import dataPreprocess
from feature_engineering import createFeatures
from model import trainModel, makePredictions
import subprocess

def runDataAnalysis(spark: SparkSession):
    try:
        preprocessedData = dataPreprocess(spark)
        features = createFeatures(preprocessedData, spark)

        model, testDf = trainModel(features)
        predictions = makePredictions(model, testDf)

        converter = IndexToString(inputCol="ProdutoIndex", outputCol="Nome do Produto")
        predictions = converter.transform(predictions)

        return predictions
    except Exception as e:
        print(f"Ocorreu um erro durante a análise de dados: {e}")
        return None

if __name__ == "__main__":
    script_path1 = r"C:\hadoop\sbin\stop-all.cmd"
    subprocess.run([script_path1], shell=True)

    script_path2 = r"C:\hadoop\sbin\start-all.cmd"
    subprocess.run([script_path2], shell=True)

    spark = SparkSession.builder \
        .appName("InventoryForecast") \
        .config("spark.hadoop.fs.defaultFS", "hdfs://localhost:9000") \
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
        .getOrCreate()

    predictions_with_names = runDataAnalysis(spark)

    if predictions_with_names is not None:
        predictions_with_names.select("Nome do Produto", "Quantidade Vendida", "prediction").show(9)
    else:
        print("Nenhuma predição retornada. Verifique a função de criar predição.")
